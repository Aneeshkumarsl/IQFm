import { Component, OnInit } from '@angular/core';

import { environment  } from '@env/environment';
import { AuthService } from '../../core/services/auth.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-nav',
    templateUrl: './nav.component.html',
    styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {
  version = environment.version;
  loggedUserName : String

  navItems = [
    { link: '/dashboard/home', title: 'Home' },
    { link: '/about', title: 'About' },
    { link: '/contact', title: 'Contact' }
  ];

  constructor(
    private auth : AuthService,
    private router: Router,

  ) { }

  ngOnInit() {
    if(this.auth.getToken()){
      this.loggedUserName = this.auth.getName()
    }
  }

  logOut(){
    this.auth.logout()
    this.router.navigate(['/auth/login'])
    return false
  }


}
