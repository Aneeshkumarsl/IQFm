import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { AuthService } from '../services/auth.service';
import { Observable, throwError } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { finalize, catchError } from 'rxjs/operators';
import { NgxSmartModalService } from 'ngx-smart-modal'


@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor(
    private auth : AuthService,
    private spinner: NgxSpinnerService,
    public modalService : NgxSmartModalService


  ) {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    
    request = request.clone({
      setHeaders: {
        Authorization: `${this.auth.getToken()}`
      }
    });
    this.spinner.show();

    return next.handle(request).pipe(
      finalize(()=>{
        let self = this;
        setTimeout(function(){
          self.spinner.hide();
        },1000)
      }),
      catchError( (error) => {
        console.log(error,"error.msg");
        const obj: Object = {
          title : "Internal Server Error",
          msg : error && error.error &&  error.error.message ? error.error.message : 'Unknown Error Occured. Please contact IT Team',
        }
        console.log(this.modalService)
        this.modalService.setModalData(obj, 'infoModal',true);
        this.modalService.getModal('infoModal').open()
        return throwError(error);
   })

    );
  }
}