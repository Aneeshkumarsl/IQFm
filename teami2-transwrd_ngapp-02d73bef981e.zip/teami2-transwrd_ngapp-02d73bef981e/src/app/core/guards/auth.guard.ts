import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import {AuthService} from '../services/auth.service';
import { Router } from '@angular/router';
import { copyStyles } from '@angular/animations/browser/src/util';

@Injectable()
export class AuthGuard implements CanActivate {
    
    constructor(
        private authService : AuthService,
        private router: Router
    ) {}

    canActivate(): boolean {
        let token = this.authService.getToken()
        if(token){
           return true;
        }

        console.log('Invalid Token Exist')
        //INVALID TOKEN EXIST
        this.router.navigate(['/auth/login']);
        return false;
    }

}
