export const config: any = {
    API_URL: 'assets/api',
    defaultLimitSearch : 100
};
