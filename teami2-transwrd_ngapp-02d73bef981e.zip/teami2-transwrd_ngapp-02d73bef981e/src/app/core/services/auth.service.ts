import { Injectable } from '@angular/core';
import { of, Observable,  } from 'rxjs';
import { User } from '../../core/models/user.model';
import {ApiService} from './api.service'
// import {AuthService} from './'

export class ILoginContext {
  userId: string;
  Password: string;
  token: string;
}

const defaultUser = {
  username: 'admin',
  password: 'admin',
  token: '12345'
};

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  token: string;
  isLoading : false;
  error : false
  constructor(
    private apiService : ApiService
  ) { }

  login(loginContext: ILoginContext): Observable<any> {
    
    // if (
    //   loginContext.userId === defaultUser.username &&
    //   loginContext.Password === defaultUser.password) {
        
    //     return of(defaultUser);
    // }


   return this.apiService.post('/auth/authenticate','users',{
      "userId":loginContext.userId,
      "password":loginContext.Password
    })
  }; 
  
  




    //   tap(login => {
    //       // console.log(login)
    //       if(login.data && login.data.status === "success"){
    //         sessionStorage.setItem('token',login.headers.get('leapauthtoken'))
    //         console.log('Token Data Stroed Into DB')
    //         return of(login.data)
    //       }else if(login.data && login.data.error === "authError"){
    //         return throwError(login.data.message)
    //       }
    //        else {
    //         return throwError('Invalid Error' + login.data.message);
    //       }
    //   }),
    //   finalize(() => this.isLoading = false),
    //   catchError(error => of(this.error = error))
    // ).subscribe(
  
    // );
      // setTimeout(function(){
      //   return throwError('Invalid Error');
      // },3000)

    
  // }

  logout(): Observable<boolean> {
    sessionStorage.removeItem('token')
    sessionStorage.removeItem('user')
    return of(false);
  }

  getToken() {
    // return this.getToken;
    return sessionStorage.getItem('token')
  }

  getName() {
    return sessionStorage.getItem('user')
  }

}
