import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { tap, map, finalize, catchError ,} from 'rxjs/operators';
import { of, throwError, from } from 'rxjs';

import { AuthService, ApiService } from '@app/core';

import { NgxSmartModalService } from 'ngx-smart-modal'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  error: string;
  isLoading: boolean;
  loginForm: FormGroup;
  userId: FormControl;
  Password: FormControl;
  showLogin: boolean;
  errorMsg: string
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private apiService : ApiService,
    public modalService : NgxSmartModalService

  ) {
    this.createFormControler();
    this.createForm();
  }


  createFormControler() {
    this.userId = new FormControl('', Validators.required);
    this.Password = new FormControl('', Validators.required);
  }

  createForm() {
    this.loginForm = new FormGroup({
      userId: this.userId,
      Password: this.Password

    })
  }
  ngOnInit() { 
    if(this.authService.getToken()){
      this.router.navigate(['/dashboard/home'])
    }else {
      this.showLogin = true
    }
  }
 

  login() {
    this.isLoading = true;
    let self = this
    const credentials = this.loginForm.value;
    if(self.loginForm.valid){
      self.router.navigate(['/dashboard/home'])
    // this.authService.login(credentials)
    //   .pipe(
    //     map(users => {
    //       if(users.body && users.body.status === "success" || true){

    //         self.router.navigate(['/dashboard/home'])
    //         sessionStorage.setItem('token',users.headers.get('leapauthtoken'))
    //         console.log('Token Data Stroed Into DB')
             
           
    //         // this.apiService.get('/employees/entitlements','users',{}).pipe(
    //         //   tap(entitlements => {
    //         //     if(entitlements && entitlements[0]){

    //         //       sessionStorage.setItem('user',entitlements[0].userName)
    //         //       self.router.navigate(['/dashboard/home'])
    //         //     }
    //         //   }),
    //         //   finalize(() => this.isLoading = false),
    //         //   catchError(error => of(this.error = error))
    //         // ).subscribe();
                        

    //       }else if(users.body && users.body.error === "authError"){
    //         this.errorMsg = users.body.error
    //         console.log(users.body.error)
           
    //         return throwError(users.body.message)
    //       }
    //        else {
    //         return throwError('Invalid Unknown Error');
    //       }

          
    //     }),
    //     finalize(() => this.isLoading = false),
    //     catchError(error => of(
    //       this.errorMsg = error.message ? error.message : 'Invalid Error',
    //       console.log(error),
    //       self.openPopUp({
    //         title : 'Login Failed',
    //         msg : error.message
    //       })

    //       ))
    //   ).subscribe();
  }else {
    self.openPopUp({
      title : 'Login Failed',
      msg : 'Please enter mandatory fields with valid information to proceed further'
    })
  }
  }

 

  openPopUp(obj) {
    console.log(obj,"obj")
    this.modalService.setModalData(obj, 'infoModal',true);
    this.modalService.getModal('infoModal').open()

  }
}
