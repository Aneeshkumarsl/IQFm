import { Component } from '@angular/core';
import { NgxSmartModalService, NgxSmartModalComponent } from 'ngx-smart-modal'
import { ModalInstance } from 'ngx-smart-modal/src/services/modal-instance';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  // infoModal : any = {}
  title = 'Co Lendng | Master | Home';
  getModal = true
  mtitle = 'Internal Server Error'
  mMsg = 'Unknown Error, Please contact Admin Team'
  mBtn = 'OK'
  constructor(
    public modalService : NgxSmartModalService
  ){

  }

  ngAfterViewInit() {
    var self = this
    this.modalService.getModal('infoModal').onDataAdded.subscribe((modal: NgxSmartModalComponent) => {
      self.mtitle = modal['title'] ? modal['title'] : self.mtitle
      self.mMsg = modal['msg'] ? modal['msg'] : self.mMsg
      self.mBtn = modal['mBtn'] ? modal['mBtn'] : self.mBtn

    });

    this.modalService.getModal('infoModal').onClose.subscribe((modal: NgxSmartModalComponent) => {
      console.log(modal['_data'],"onclose")
    }) 
  }

}
