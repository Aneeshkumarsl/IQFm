import { Component, Input, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnInit {

  @Input() public isLoading = false;
  @Input() public message: string;

  constructor(
    private spinner: NgxSpinnerService

  ) { }

  public ngOnInit(): void {
    // console.log(this.spinner.show)

  //   setTimeout(() => {
  //     /** spinner ends after 5 seconds */
  //     this.spinner.show();
  //     console.log("spin start")
  //     setTimeout(()=>{
  //       this.spinner.hide();

  //     },2000)
  // }, 5000);
    
   }

}
