import { TestBed } from '@angular/core/testing';

import { DataTrasferService } from './data-trasfer.service';

describe('DataTrasferService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DataTrasferService = TestBed.get(DataTrasferService);
    expect(service).toBeTruthy();
  });
});
