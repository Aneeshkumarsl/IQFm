export const environment = {
  production: true,
  serverUrl : "http://127.0.0.1:3008/mastersapi",
  envName : 'Production',
  version : 'v0.1'
};
